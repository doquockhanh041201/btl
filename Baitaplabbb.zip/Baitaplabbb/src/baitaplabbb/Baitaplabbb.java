
package baitaplabbb;


public class Baitaplabbb {

    public static void main(String[] args) {
        // TODO code application logic here
        LoginAcc log = new LoginAcc();
        log.show();
    }
    
}
